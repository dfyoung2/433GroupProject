library("readxl")
library("tidyverse")
filepath = "nutrition_data.xlsx"
nutrition_df <- read_excel(filepath)

h_to_l_rankings <- c(1,2,3,4,5)
h_to_l_rankings <- as.data.frame(h_to_l_rankings)

for (nutrient in colnames(nutrition_df)){
  print(nutrient)
  tmp <- slice_max(nutrition_df, nutrition_df[nutrient], n=5, with_ties = FALSE)
  h_to_l_rankings[nutrient] <- tmp["Shrt_Desc"]
  print(tmp["Shrt_Desc"])
}

h_to_l_rankings <- h_to_l_rankings[,-2:-3]

View(h_to_l_rankings)



l_to_h_rankings <- c(1,2,3,4,5)
l_to_h_rankings <- as.data.frame(l_to_h_rankings)

for (nutrient in colnames(nutrition_df)){
  print(nutrient)
  tmp <- slice_max(nutrition_df, nutrition_df[nutrient], n=5, with_ties = FALSE)
  l_to_h_rankings[nutrient] <- tmp["Shrt_Desc"]
  print(tmp["Shrt_Desc"])
}

l_to_h_rankings <- l_to_h_rankings[,-2:-3]

View(l_to_h_rankings)

